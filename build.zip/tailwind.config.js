/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js,ts,jsx,tsx}"],
  theme: {
    extend: {
      filter: {
        'custom-blue': 'invert(31%) sepia(27%) saturate(1156%) hue-rotate(207deg) brightness(93%) contrast(90%)',
      },
      screens: {
        '3xl': '1920px',
        '4xl': '2560px',
      },
      colors: {
        ink: {
          DEFAULT: '#0E1B2E',
          soft: '#16263D',
        },
        paper: {
          DEFAULT: '#EEF1F5',
          line: '#D7DBE2',
        },
        gold: {
          DEFAULT: '#C8973B',
          soft: '#E3C081',
        },
        teal: {
          DEFAULT: '#1F5C57',
          soft: '#2F786F',
        },
        slate: {
          DEFAULT: '#3A4250',
          soft: '#6B7280',
        },
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        body: ['Manrope', '-apple-system', 'sans-serif'],
        mono: ['"IBM Plex Mono"', '"Courier New"', 'monospace'],
      },
    },
  },
  plugins: [],
}